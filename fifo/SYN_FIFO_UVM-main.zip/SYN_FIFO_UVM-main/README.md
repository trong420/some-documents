# SYN_FIFO_UVM
DUT:

A basic synchronous FIFO (First-In-First-Out).
Size: Width 8 * Depth 16 

<br />
<br />

Testbench:

Tested on Synopsys VCS.

2 basic scenarios: 1) Write 16 data packets then read all 16 data packets. 2) Do write and read randomly and continuously for 20 times.

